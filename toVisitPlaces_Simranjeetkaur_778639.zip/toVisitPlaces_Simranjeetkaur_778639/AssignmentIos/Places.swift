//
//  PlaceList.swift
//  AssignmentIos
//
//  Created by user176097 on 6/14/20.
//  Copyright © 2020 Simranjeet kaur. All rights reserved.
//

import Foundation

let placeObj = Places()

class Places {
    
    var favPlaces = [Place] ()
//    
//    init() {
//        self.favPlaces = getPlace()
//    }
//
//    func savePlace(){
//        UserDefaults.standard.set(favPlaces, forKey: "favouritePlace")
//    }
//    func  getPlace()-> [Place] {
//        var plist =  UserDefaults.standard.array(forKey: "favouritePlace") as? [Place]
//        if plist == nil {
//            plist = [Place] ()
//        }
//        return plist!
//    }

}
